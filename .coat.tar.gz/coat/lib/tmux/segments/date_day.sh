# Prints the name of the current day.

run_segment() {
	date +"%a"
	return 0
}
