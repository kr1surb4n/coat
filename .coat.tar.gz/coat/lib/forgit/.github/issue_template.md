<!-- ISSUES NOT FOLLOWING THIS TEMPLATE WILL BE CLOSED AND DELETED -->

<!-- Check all that apply [x] -->

## Check list

- [ ] I have read through the [README](https://github.com/wfxr/forgit/blob/master/README.md)
- [ ] I have the latest version of forgit
- [ ] I have searched through the existing issues

## Environment info

- OS
    - [ ] Linux
    - [ ] Mac OS X
    - [ ] Windows
    - [ ] Others:
- Shell
    - [ ] bash
    - [ ] zsh
    - [ ] fish

## Problem / Steps to reproduce
