#!/bin/bash
alias dc='docker-compose'
