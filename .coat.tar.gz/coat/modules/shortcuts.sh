#!/bin/bash

bind -x '"\es": spellcast'
bind -x '"\ew": spellforge'

bind -x '"\eb": shellsnip'
bind -x '"\en": netspells'

bind -x '"\eg": cdg'
bind -x '"\et": teleports'
bind "\M-z":kit
