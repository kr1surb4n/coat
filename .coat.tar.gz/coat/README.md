coat
====

YOU RUN THIS SOFTWARE ON YOUR OWN.

set of scripts and libraries, and helpers 
and stuff, that end up being a huge ease with working
on unix
