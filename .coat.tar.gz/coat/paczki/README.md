Pączki
------
Set of commonly used files by my inside project.

The idea is to use the `paczekfiller`, which
using fzf, lists all the files in this repository.
User then chooses those files and places them in his
current directory. 
If the files is a Jinja2 template, ending with `.tpl`
extension, then the `paczekfiller` will extract the
template variables and prompt user for values. 

TODO
----
jenkins (is quite empty, maybe the python-jenkins scripts )
org   (do i really need there something?)
envrc (add variables from makefiles)
python/django/Makefile  (remove garbage)