#!/usr/bin/env bash
# Bash completion support for  RVM.
# Source: https://rvm.io/workflow/completion

[[ -r $rvm_path/scripts/completion ]] && . $rvm_path/scripts/completion
