#!/bin/bash

git config --global commit.template ~/.gitmessage
